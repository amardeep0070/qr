/**
 * Created by Amardeep on 08/10/16.
 */
//to avoid namespace duplication and clutter we use this.
//Best Practice.
(function () {
    angular.module("TwitterSearch",["ngRoute"]);
})();