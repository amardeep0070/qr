/**
 * Created by Saibi on 23/10/2016.
 */
module.exports = function(app) {
    require("./services/search.service.server")(app);

};